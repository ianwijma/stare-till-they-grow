package dev.tmp.StaringMod.Network.Message;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.IGrowable;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

public class LookedAtGrowable {

    private final double x;
    private final double y;
    private final double z;

    public LookedAtGrowable( double x, double y, double z ) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public LookedAtGrowable ( BlockPos blockPos ) {
        this.x = blockPos.getX();
        this.y = blockPos.getY();
        this.z = blockPos.getZ();
    }

    public static void encode(LookedAtGrowable msg, PacketBuffer buf) {
        buf.writeDouble( msg.x );
        buf.writeDouble( msg.y );
        buf.writeDouble( msg.z );
    }

    public static LookedAtGrowable decode(PacketBuffer buf) {
        double x = buf.readDouble();
        double y = buf.readDouble();
        double z = buf.readDouble();
        return new LookedAtGrowable( x, y, z );
    }

    public static void handle( final LookedAtGrowable lookedAtGrowable, final Supplier<NetworkEvent.Context> ctx) {
        if ( ctx.get().getDirection().getReceptionSide().isServer() ) {
            ctx.get().enqueueWork(() -> {
                ServerPlayerEntity player = ctx.get().getSender();
                if ( null != player ) {
                    ServerWorld world = player.getServerWorld();
                    BlockPos blockPos = lookedAtGrowable.getBlockPos();
                    BlockState blockState = world.getBlockState( blockPos );
                    Block block = blockState.getBlock();
                    if ( block instanceof IGrowable ) {
                        IGrowable iGrowable = (IGrowable) block;
                        if ( iGrowable.canUseBonemeal( world, world.rand, blockPos, blockState ) ) {
                            iGrowable.grow( world, world.rand, blockPos, blockState );
                        }
                    }
                }
            });
        }
    }

    public BlockPos getBlockPos () {
        return new BlockPos( this.x, this.y, this.z );
    }

}
