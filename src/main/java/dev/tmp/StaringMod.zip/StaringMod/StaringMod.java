package dev.tmp.StaringMod;

import dev.tmp.StaringMod.Network.Network;
import dev.tmp.StaringMod.Utilities.PlayerEventHandlers;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod("staringmod")
public class StaringMod
{
    public static String MODE_ID = "staringmod";

    public StaringMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener( this::commonSetup );

        IEventBus forgeEventBus = MinecraftForge.EVENT_BUS;
        forgeEventBus.register( new PlayerEventHandlers() );
    }

    private void commonSetup ( FMLCommonSetupEvent event ) {
        Network.init();
    }
}
