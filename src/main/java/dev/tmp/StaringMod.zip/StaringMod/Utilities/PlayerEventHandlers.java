package dev.tmp.StaringMod.Utilities;

import com.sun.media.jfxmedia.events.PlayerEvent;
import dev.tmp.StaringMod.Network.Message.LookedAtGrowable;
import dev.tmp.StaringMod.Network.Network;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.IGrowable;
import net.minecraft.block.SaplingBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.text.MessageFormat;

public class PlayerEventHandlers {

    @SubscribeEvent
    public void pickupItem (FOVUpdateEvent event) {
        World world = event.getEntity().world;
        RayTraceResult lookingAt = Minecraft.getInstance().objectMouseOver;
        if ( null != lookingAt && lookingAt.getType() == RayTraceResult.Type.BLOCK ) {
            Vector3d vec = lookingAt.getHitVec();
            BlockPos blockPos = new BlockPos( vec.x, vec.y, vec.z );
            BlockState blockState = world.getBlockState( blockPos );

            if ( blockState.getBlock() instanceof IGrowable ) {
                IGrowable iGrowable = (IGrowable) blockState.getBlock();
                if ( iGrowable.canGrow(world, blockPos, blockState, world.isRemote) ) {
                    Network.sendToServer(new LookedAtGrowable( blockPos ));
                }
            }

        }
    }

}
